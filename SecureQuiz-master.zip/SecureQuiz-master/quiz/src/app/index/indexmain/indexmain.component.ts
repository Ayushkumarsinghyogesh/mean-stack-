import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indexmain',
  templateUrl: './indexmain.component.html',
  styleUrls: ['./indexmain.component.css']
})
export class IndexmainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
