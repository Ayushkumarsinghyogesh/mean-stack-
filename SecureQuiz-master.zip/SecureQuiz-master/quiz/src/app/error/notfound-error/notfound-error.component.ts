import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notfound-error',
  templateUrl: './notfound-error.component.html',
  styleUrls: ['./notfound-error.component.css']
})
export class NotfoundErrorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
