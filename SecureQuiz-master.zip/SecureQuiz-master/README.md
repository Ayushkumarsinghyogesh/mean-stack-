# SecureQuiz

### Backend Src-code : <a href="https://github.com/shekhutsav1962001/QuizyBackend">view</a>

### video of running project = <a href="https://youtu.be/OjiEuqY0gww">Link</a>

- ## How To run Front-end App(Angular)

```javascript
$ git clone https://github.com/shekhutsav1962001/SecureQuiz.git
$ cd SecureQuiz
$ cd quiz
$ npm install
$ ng serve 
```